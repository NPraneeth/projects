<form>
<select id="yy" type="input" name="year" required >
   <option selected disabled value="">Choose year</option>
   <option>1</option>
   <option>2</option>
   <option>3</option>
   <option>4</option>
  
  
   </select>
<input type="text" value="" required>
<input type="submit" value="submit">
</form>
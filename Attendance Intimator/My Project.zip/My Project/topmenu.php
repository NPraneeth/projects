<img src="banner.jpg" width="100%"height="120px" style="margin:0;">
 <!--<span id="mylogo" style="">On'DriVe</span>-->

 <!--<table width="80%" border="0" style="position:absolute;top:0;">
 <tr>
 <img src="aitamban.gif" height="70px" style="margin-left:50px;"><br>
<h4 style="margin-left:125px;margin-top:-3px;color:purple;">AN <B>AUTONOMOUS</B> INSTITUTION & AFFILIATED TO <B>JNTUKAKINADA</B></h4>
 </tr>
 
 

 </table>
 <span id="mylogo" style="">On'DriVe</span>-->
<!--<div style="display:block;position:absolute;top:30%;left:30%;padding:50px;background:#014965;color:white;font-size:3em;">Coming Soon ...</div>-->
<div id="menu">
<ul>
<li><a href="welcome.php">HOME</a></li>
<li><a href="att.php">ATTENDANCE REPORT</a></li>
<li><a href="c_report.php">COUNSELLING REPORT</a></li>
<!-- <li><a href="acc.php">ACCOUNT</a></li> -->
<li><a href="logout.php">LOGOUT</a></li>
</ul>
</div>